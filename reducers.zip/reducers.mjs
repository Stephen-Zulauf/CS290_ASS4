/* 
* TODO: add your First Name Last Name.
*/

/*
* Don't change the declaration of this function.
*/
function reducer1(previousValue, currentValue){
    // TODO: Write your code here
};

/*
* Don't change the declaration of this function.
*/
function reducer2(previousValue, currentValue){
    // TODO: Write your code here
};


// Don't add or change anything below this comment.
export { reducer1, reducer2 };