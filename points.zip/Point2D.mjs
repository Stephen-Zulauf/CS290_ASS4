/* 
* TODO: add your First Name Last Name.
*/

/*
* Don't change the starter code we have provided in this file.
* Add your code where we have added TODO comments.
* If you want, you can remove the TODO comments. Your choice.
*/

/**
 * Models a point in 2 dimensions
 */
class Point2D {
    /**
     * 
     * @param {number} x The x-coordinate of the point
     * @param {number} y The y-coordinate of the point
     */
    constructor(x, y) {
        // TODO: Write your code here
    }

    /**
     * 
     * @param {object} p An instance of the class Point2Dim
     * @returns The Euclidean distance between this point and p
     */
    distanceFrom(p) {
        // TODO: Write your code here
    }
}

export {Point2D}